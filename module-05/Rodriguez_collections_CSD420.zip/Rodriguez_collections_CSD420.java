//Carolina Rodriguez
//CSD 420
//This program reads a collection of words from a file and sorts them in both ascending and descending order using Java Collections.

//Resources used:
//W3Schools. (n.d.). Java ArrayList sort() method.https://www.w3schools.com/java/ref_arraylist_sort.asp
//GeeksforGeeks. (2025, January 4). Collections.sort() in Java with examples.https://www.geeksforgeeks.org/java/collections-sort-java-examples/
//Lifshitz, R. (2018, May 22). Why not Set<String> set = new HashSet() instead of Set<String> set = new HashSet<String>()? Stack Overflow
//https://stackoverflow.com/questions/50458772/why-not-setstring-set-new-hashset-instead-of-setstring-set-new-hashset
//GeeksforGeeks. (2025, July 11). HashSet in Java.https://www.geeksforgeeks.org/java/hashset-in-java/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Rodriguez_collections_CSD420 {

    public static void main(String[] args) {
        String filename = "collection_of_words.txt";

        try {
            Set<String> nameUnique = readWordsFromFile(filename);// Read words from file into a Set to ensure uniqueness

            List<String> wordList = new ArrayList<>(nameUnique); // Convert Set to List for sorting

            Collections.sort(wordList); // Sort in ascending order
            System.out.println("Ascending order:");
            for (String word : wordList) {
                System.out.print(word + " ");
            }

            System.out.println("\n");

            Collections.sort(wordList, Collections.reverseOrder()); // Sort in descending order
            System.out.println("Descending order:");
            for (String word : wordList) {
                System.out.print(word + " ");
            }

        } catch (FileNotFoundException e) { //test for file not found exception
            System.out.println("File not found: " + filename);
        }
    }

    public static Set<String> readWordsFromFile(String filename) throws FileNotFoundException {
        Set<String> words = new HashSet<>(); // Use a HashSet to store words to ensure uniqueness
        Scanner scanner = new Scanner(new File(filename));

        while (scanner.hasNext()) {// Read each word from the file and add it to the Set
            String word = scanner.next();
            words.add(word);
        }

        scanner.close();
        return words;
    }
}