//Carolina Rodriguez
//CSd-420 Assignment 9 
//Show Java code to connect to a database and show the results.

//Resources used:
//Microsoft. (n.d.). Settings JSON file. Visual Studio Code Documentation. https://code.visualstudio.com/docs/configure/settings#_settings-json-file
//Payne, D. (2026). Display database table data.[Unpublished class handout]. CSD 420. Bellevue University.
//OpenAI. (2026). ChatGPT (GPT-5.3) [Large language model]. https://chat.openai.com/


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ShowDatabase {

    public static void main(String[] args) {
        try {
            String url = "jdbc:mysql://localhost:3306/databasedb";
            String user = "student1";
            String password = "pass";

            Connection con = DriverManager.getConnection(url, user, password); //connect to the database

            System.out.println("Connection established - now executing a select"); 

            Statement stmt = con.createStatement(); //create a statement object to execute the query
            ResultSet rs = stmt.executeQuery("SELECT * FROM address33");

            System.out.println("Received Results:");

            int columns = rs.getMetaData().getColumnCount(); //get the number of columns in the result set

            while (rs.next()) { //iterate through the result set and print each row
                for (int x = 1; x <= columns; x++) {
                    System.out.print(rs.getString(x) + " ");
                }
                System.out.println();
            }

            rs.close();
            stmt.close();
            con.close();

        } catch (Exception ex) {
            ex.printStackTrace(); //print the stack trace if an exception occurs
        }
    }
}